class ReviewPost < ApplicationRecord
end
