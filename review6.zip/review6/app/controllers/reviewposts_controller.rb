class ReviewpostsController < ApplicationController
  def index
  end

  def show
  end

  def new
    @review = Review.new
  end

  def edit
  end
end
