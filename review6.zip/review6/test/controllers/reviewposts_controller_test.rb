require 'test_helper'

class ReviewpostsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get reviewposts_index_url
    assert_response :success
  end

  test "should get show" do
    get reviewposts_show_url
    assert_response :success
  end

  test "should get new" do
    get reviewposts_new_url
    assert_response :success
  end

  test "should get edit" do
    get reviewposts_edit_url
    assert_response :success
  end

end
