require 'test_helper'

class ReviewPostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
